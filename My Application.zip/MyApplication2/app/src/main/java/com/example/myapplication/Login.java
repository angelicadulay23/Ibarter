package com.example.myapplication;

import android.app.Activity;

public class Login extends Activity {
}
